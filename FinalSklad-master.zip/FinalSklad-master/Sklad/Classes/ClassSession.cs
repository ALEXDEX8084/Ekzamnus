﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sklad.Classes
{
    internal class ClassSession
    {
        public static int idSession;
        public static int countMed;
        public static int Type;
    }
}
